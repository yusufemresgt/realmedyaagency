@echo off
chcp 65001 >nul
title Real Medya Agency Site
echo Real Medya Agency sitesi aciliyor...
start "" "%~dp0index.html"
echo Site tarayicida acildi. Bu pencereyi kapatabilirsiniz.
pause
