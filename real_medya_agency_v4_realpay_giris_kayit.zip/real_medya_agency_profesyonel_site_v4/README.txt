REAL MEDYA AGENCY PROFESYONEL SITE - V4

Yenilikler:
- RealPay sayfasına RealPay puan kartı görseli eklendi.
- TikTok Universal, Aslan ve Yıldızlar Arası hediyeleri RealPay mağazasına eklendi.
- WhatsApp ve Instagram gerçek logo görselleri eklendi.
- WhatsApp: +90 539 834 23 01
- WhatsApp sahibi: Batuhan Şahin
- Giriş Yap ve Kayıt Ol sayfaları eklendi.
- TikTok ile oturum aç ve Google ile oturum aç butonları eklendi.
- Admin paneline kayıtlı üyeler tablosu eklendi.

NOT: Bu sürüm statik sitedir. Site içi kayıt/giriş localStorage ile çalışır. Gerçek TikTok/Google OAuth için canlı domain, sunucu ve API client bilgileri gerekir.

Kullanım:
1) ZIP'i çıkar.
2) start.bat dosyasına çift tıkla.
3) Olmazsa index.html dosyasına çift tıkla.

Admin paneli: admin.html
Admin şifresi: real2026
